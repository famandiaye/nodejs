const mysql = require('mysql');
//connection a la base de donnee
const con = mysql.createConnecton({
    host: "localhost",
    user: "root",
    password: "famaguiro",
    database: "ISEP_TV"
});


//verification de la connection
con.connect((error)=> {
    if(error){
        console.erreur("erreur de connection " + error.stack);
        return ;
    }
    console.log("connection reussi")
});

//selectionner un film
con.query("select * from films ", (error, rows, fields)=>{
    if(error) throw error;
        console.log("les donnees sont ", rows);
    
});

module.exports = { con };