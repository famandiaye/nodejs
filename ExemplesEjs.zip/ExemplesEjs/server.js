const express = require('express');
const app = express();

const PORT = 3000;
const copyright ="Fama 2024";

//dire a express de considerer le dossier public comme un dossier contenant des fichiers accessible par les clients
app.use('/public', express.static('public'));



//pour dire que les vues seront dans le dossier ./views
app.set('views', './views');

// Importer la logique de la base de données
const { con } = require('./database');


const con = express();
app.get('/', (req, res)=>{
    const title = 'Isep TV show';
    
    const films = [
        {
            id:1,
            title: 'one piece',
            year:'2024',
            author: 'Alioune Diop',
        },
        {
            id:2,
            title: 'bete bete',
            year:'2024',
            author: 'Eventprod',
        },
    ];
    const data = {
        title: title,
        nom: 'fama',
        films: films,
        copyright: copyright
    }
    res.render('accueil.ejs', data);
});


app.listen(PORT, ()=>{
    console.log("server listening on port: " + PORT);
});